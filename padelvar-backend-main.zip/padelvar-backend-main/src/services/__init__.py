"""
Services de l'application PadelVar
"""

from .video_capture_service import video_capture_service

__all__ = ['video_capture_service']
